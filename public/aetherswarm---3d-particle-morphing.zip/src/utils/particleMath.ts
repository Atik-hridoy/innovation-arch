/**
 * Procedural coordinate generators and mathematical functions
 * for GPU 3D Particle Swarm Morphing.
 */

export interface ParticleBufferData {
  sphere: Float32Array;
  wave: Float32Array;
  torus: Float32Array;
  rand: Float32Array;
}

/**
 * Generates Fibonacci sphere points (default 70%) and a tilted Saturn-like outer ring (default 30%).
 */
export function generateFibonacciSphereAndRing(
  count: number,
  sphereRatio = 0.7,
  sphereRadius = 2.4,
  ringInner = 3.2,
  ringOuter = 5.2,
  tiltAngleRad = 0.48 // ~27.5 degrees
): Float32Array {
  const buffer = new Float32Array(count * 3);
  const sphereCount = Math.floor(count * sphereRatio);
  const ringCount = count - sphereCount;
  const phi = Math.PI * (3 - Math.sqrt(5)); // Golden angle

  // 1. Fibonacci Sphere Shell
  for (let i = 0; i < sphereCount; i++) {
    const y = 1 - (i / Math.max(1, sphereCount - 1)) * 2; // -1 to 1
    const radiusAtY = Math.sqrt(Math.max(0, 1 - y * y));
    const theta = phi * i;

    buffer[i * 3 + 0] = Math.cos(theta) * radiusAtY * sphereRadius;
    buffer[i * 3 + 1] = y * sphereRadius;
    buffer[i * 3 + 2] = Math.sin(theta) * radiusAtY * sphereRadius;
  }

  // 2. Saturn-like tilted planar ring
  const cosT = Math.cos(tiltAngleRad);
  const sinT = Math.sin(tiltAngleRad);

  for (let i = 0; i < ringCount; i++) {
    const idx = sphereCount + i;
    // Uniform area distribution across an annulus: r = sqrt(rand * (R2^2 - R1^2) + R1^2)
    // Deterministic pseudo-random seed based on index
    const pseudoRand = ((i * 9301 + 49297) % 233280) / 233280;
    const pseudoAngle = ((i * 12345 + 67891) % 233280) / 233280;
    const pseudoThickness = ((i * 54321 + 13579) % 233280) / 233280;

    const r = Math.sqrt(pseudoRand * (ringOuter * ringOuter - ringInner * ringInner) + ringInner * ringInner);
    const theta = pseudoAngle * Math.PI * 2;

    const lx = r * Math.cos(theta);
    const ly = (pseudoThickness - 0.5) * 0.15; // thin disk thickness
    const lz = r * Math.sin(theta);

    // Tilt around Z axis
    buffer[idx * 3 + 0] = lx * cosT - ly * sinT;
    buffer[idx * 3 + 1] = lx * sinT + ly * cosT;
    buffer[idx * 3 + 2] = lz;
  }

  return buffer;
}

/**
 * Generates an undulating 3D sine/cosine wave terrain grid.
 */
export function generateWaveTerrain(
  count: number,
  width = 13.0,
  depth = 11.0,
  heightScale = 0.7,
  yOffset = -1.8
): Float32Array {
  const buffer = new Float32Array(count * 3);
  const gridDim = Math.ceil(Math.sqrt(count));

  for (let i = 0; i < count; i++) {
    const col = i % gridDim;
    const row = Math.floor(i / gridDim);

    const u = (col / Math.max(1, gridDim - 1) - 0.5) * width;
    const v = (row / Math.max(1, gridDim - 1) - 0.5) * depth;
    const y = Math.sin(u * 0.75) * Math.cos(v * 0.75) * heightScale + yOffset;

    buffer[i * 3 + 0] = u;
    buffer[i * 3 + 1] = y;
    buffer[i * 3 + 2] = v;
  }

  return buffer;
}

/**
 * Generates a hollow torus ring oriented in 3D space.
 */
export function generateTorus(
  count: number,
  majorRadius = 2.8,
  minorRadius = 0.85
): Float32Array {
  const buffer = new Float32Array(count * 3);
  const goldenAngle = Math.PI * (3 - Math.sqrt(5));

  for (let i = 0; i < count; i++) {
    // Distribute u evenly across full 360 degrees [0, 2*PI]
    const u = (i / Math.max(1, count)) * Math.PI * 2;
    // Golden angle distribution around minor tube circle
    const v = i * goldenAngle;

    buffer[i * 3 + 0] = (majorRadius + minorRadius * Math.cos(v)) * Math.cos(u);
    buffer[i * 3 + 1] = (majorRadius + minorRadius * Math.cos(v)) * Math.sin(u);
    buffer[i * 3 + 2] = minorRadius * Math.sin(v);
  }

  return buffer;
}

/**
 * Generates per-particle random seeds for lag, scale variance, and turbulence.
 */
export function generateRandomSeeds(count: number): Float32Array {
  const buffer = new Float32Array(count * 3);
  for (let i = 0; i < count; i++) {
    // Generate high-entropy seeds between 0 and 1
    const s1 = ((i * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff;
    const s2 = ((i * 1664525 + 1013904223) & 0x7fffffff) / 0x7fffffff;
    const s3 = ((i * 214013 + 2531011) & 0x7fffffff) / 0x7fffffff;

    buffer[i * 3 + 0] = s1;
    buffer[i * 3 + 1] = s2;
    buffer[i * 3 + 2] = s3;
  }
  return buffer;
}

/**
 * Returns default color triples optimized for dark vs light canvas backgrounds.
 * Light backgrounds require high pigment saturation and normal blending.
 */
export function getDefaultColors(mode: 'dark' | 'light') {
  if (mode === 'light') {
    return {
      sphere: '#0284c7', // Deep Sky Cobalt
      wave: '#7c3aed',   // Rich Royal Purple
      torus: '#ea580c',  // Deep Flame Amber
    };
  }
  return {
    sphere: '#38bdf8', // Radiant Starlight Cyan
    wave: '#c084fc',   // Neon Violet
    torus: '#fb923c',  // Solar Amber
  };
}

/**
 * Pure helper matching the GLSL vertex shader staggered swarm lag math.
 */
export function calculateStaggeredProgress(
  stageProgress: number,
  lagMultiplier: number,
  randSeed: number
): number {
  const clampedProgress = Math.max(0, Math.min(1, stageProgress));
  const lag = randSeed * lagMultiplier;
  const localProgress = Math.max(0, Math.min(1, (clampedProgress - lag) / (1.0 - lagMultiplier)));
  // smoothstep(0, 1, localProgress)
  return localProgress * localProgress * (3 - 2 * localProgress);
}
