import test from 'node:test';
import assert from 'node:assert/strict';
import {
  generateFibonacciSphereAndRing,
  generateWaveTerrain,
  generateTorus,
  generateRandomSeeds,
  calculateStaggeredProgress,
  getDefaultColors,
} from './particleMath';

test('Fibonacci sphere & ring generation produces exact coordinates and valid ranges', () => {
  const count = 9000;
  const buffer = generateFibonacciSphereAndRing(count, 0.7, 2.4, 3.2, 5.2, 0.48);
  assert.equal(buffer.length, count * 3);

  // Check first point (top of sphere)
  assert.ok(!Number.isNaN(buffer[0]));
  assert.ok(!Number.isNaN(buffer[1]));
  assert.ok(!Number.isNaN(buffer[2]));

  // Verify sphere shell points lie within sphere radius tolerance
  const sphereCount = Math.floor(count * 0.7);
  for (let i = 0; i < 50; i++) {
    const x = buffer[i * 3];
    const y = buffer[i * 3 + 1];
    const z = buffer[i * 3 + 2];
    const dist = Math.sqrt(x * x + y * y + z * z);
    assert.ok(Math.abs(dist - 2.4) < 0.05, `Point ${i} distance ${dist} must be approx 2.4`);
  }

  // Verify ring points lie within ring radius limits (3.2 to 5.2)
  for (let i = sphereCount; i < sphereCount + 50; i++) {
    const x = buffer[i * 3];
    const y = buffer[i * 3 + 1];
    const z = buffer[i * 3 + 2];
    const dist = Math.sqrt(x * x + y * y + z * z);
    assert.ok(dist >= 3.1 && dist <= 5.3, `Ring point ${i} distance ${dist} should be in ring bounds`);
  }
});

test('Wave terrain generates valid grid coordinates and undulation', () => {
  const count = 9000;
  const buffer = generateWaveTerrain(count, 13.0, 11.0, 0.7, -1.8);
  assert.equal(buffer.length, count * 3);

  // Check bounds
  for (let i = 0; i < count; i += 100) {
    const x = buffer[i * 3];
    const y = buffer[i * 3 + 1];
    const z = buffer[i * 3 + 2];

    assert.ok(x >= -7.0 && x <= 7.0, `X coordinate out of bounds: ${x}`);
    assert.ok(z >= -6.0 && z <= 6.0, `Z coordinate out of bounds: ${z}`);
    assert.ok(y >= -2.6 && y <= -1.0, `Y coordinate out of expected terrain range: ${y}`);
  }
});

test('Torus generation conforms to major and minor radii bounds', () => {
  const count = 9000;
  const major = 2.8;
  const minor = 0.85;
  const buffer = generateTorus(count, major, minor);
  assert.equal(buffer.length, count * 3);

  for (let i = 0; i < 100; i++) {
    const x = buffer[i * 3];
    const y = buffer[i * 3 + 1];
    const z = buffer[i * 3 + 2];

    const xyDist = Math.sqrt(x * x + y * y);
    assert.ok(xyDist >= major - minor - 0.01 && xyDist <= major + minor + 0.01);
    assert.ok(Math.abs(z) <= minor + 0.01);
  }
});

test('Random seeds are bounded between 0 and 1 with good distribution', () => {
  const count = 9000;
  const buffer = generateRandomSeeds(count);
  assert.equal(buffer.length, count * 3);

  for (let i = 0; i < 200; i++) {
    const s1 = buffer[i * 3];
    const s2 = buffer[i * 3 + 1];
    const s3 = buffer[i * 3 + 2];

    assert.ok(s1 >= 0 && s1 <= 1);
    assert.ok(s2 >= 0 && s2 <= 1);
    assert.ok(s3 >= 0 && s3 <= 1);
  }
});

test('Staggered swarm progress correctly delays points and completes at 1.0', () => {
  // At progress 0, all points are 0
  assert.equal(calculateStaggeredProgress(0.0, 0.4, 0.0), 0);
  assert.equal(calculateStaggeredProgress(0.0, 0.4, 0.8), 0);

  // For high random seed (lag = 0.4 * 0.9 = 0.36), progress 0.2 has not started yet
  const delayedPoint = calculateStaggeredProgress(0.2, 0.4, 0.9);
  assert.equal(delayedPoint, 0);

  // Early point (seed 0) is well underway at progress 0.2
  const earlyPoint = calculateStaggeredProgress(0.2, 0.4, 0.0);
  assert.ok(earlyPoint > 0);

  // At progress 1.0, both points reach 1.0
  assert.equal(calculateStaggeredProgress(1.0, 0.4, 0.0), 1.0);
  assert.equal(calculateStaggeredProgress(1.0, 0.4, 1.0), 1.0);
});

test('getDefaultColors returns appropriate colors with valid hex format for both dark and light modes', () => {
  const dark = getDefaultColors('dark');
  const light = getDefaultColors('light');

  assert.match(dark.sphere, /^#[0-9a-fA-F]{6}$/);
  assert.match(dark.wave, /^#[0-9a-fA-F]{6}$/);
  assert.match(dark.torus, /^#[0-9a-fA-F]{6}$/);

  assert.match(light.sphere, /^#[0-9a-fA-F]{6}$/);
  assert.match(light.wave, /^#[0-9a-fA-F]{6}$/);
  assert.match(light.torus, /^#[0-9a-fA-F]{6}$/);

  // Light mode colors should have distinct deep pigments from dark mode
  assert.notEqual(light.sphere, dark.sphere);
});
