import React, { useState, useEffect } from 'react';
import ParticleScene, { PARTICLE_COUNT, isSoftwareGl } from './ParticleScene';
import {
  Sliders,
  Sparkles,
  Layers,
  Code2,
  ChevronDown,
  ChevronUp,
  RotateCcw,
  Maximize2,
  Eye,
  Check,
  CheckCircle2,
  Copy,
  Zap,
  X,
  Sun,
  Moon
} from 'lucide-react';

interface ColorTheme {
  name: string;
  sphere: string;
  wave: string;
  torus: string;
}

const DARK_THEMES: ColorTheme[] = [
  {
    name: 'Cosmic Aether',
    sphere: '#38bdf8', // Cyan
    wave: '#c084fc',   // Purple
    torus: '#fb923c',  // Amber
  },
  {
    name: 'Cyberpunk Neon',
    sphere: '#34d399', // Emerald
    wave: '#818cf8',   // Indigo
    torus: '#f43f5e',  // Rose
  },
  {
    name: 'Solar Flare',
    sphere: '#fde047', // Solar Gold
    wave: '#fb923c',   // Orange
    torus: '#ef4444',  // Crimson
  },
  {
    name: 'Deep Oceanic',
    sphere: '#22d3ee', // Cyan
    wave: '#3b82f6',   // Electric Blue
    torus: '#a855f7',  // Violet
  },
];

const LIGHT_THEMES: ColorTheme[] = [
  {
    name: 'Sapphire Ink',
    sphere: '#0284c7', // Deep Cobalt
    wave: '#7c3aed',   // Rich Amethyst
    torus: '#ea580c',  // Saturated Flame Amber
  },
  {
    name: 'Forest Emerald',
    sphere: '#059669', // Deep Emerald
    wave: '#4f46e5',   // Royal Indigo
    torus: '#e11d48',  // Crimson Rose
  },
  {
    name: 'Nordic Terracotta',
    sphere: '#2563eb', // Royal Blue
    wave: '#0d9488',   // Deep Teal
    torus: '#d97706',  // Warm Terracotta
  },
  {
    name: 'Obsidian Minimal',
    sphere: '#0f172a', // Obsidian Charcoal
    wave: '#334155',   // Deep Slate
    torus: '#64748b',  // Muted Slate
  },
];

export default function App() {
  const [mode, setMode] = useState<'dark' | 'light'>('dark');
  const [selectedThemeIndex, setSelectedThemeIndex] = useState(0);
  const [turbulence, setTurbulence] = useState(1.0);
  const [pointSize, setPointSize] = useState(38);
  const [isDockCollapsed, setIsDockCollapsed] = useState(false);
  const [showCodeModal, setShowCodeModal] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [activeStage, setActiveStage] = useState<'planet' | 'wave' | 'torus'>('planet');

  const themes = mode === 'light' ? LIGHT_THEMES : DARK_THEMES;
  const currentTheme = themes[selectedThemeIndex] || themes[0];
  const isLight = mode === 'light';

  // Listen for 'H' keyboard shortcut to toggle HUD per guidelines
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'h' || e.key === 'H') {
        setIsDockCollapsed(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const toggleMode = () => {
    setMode(prev => {
      const nextMode = prev === 'dark' ? 'light' : 'dark';
      setSelectedThemeIndex(0); // Reset to primary theme of that mode
      return nextMode;
    });
  };

  const scrollToPhase = (phase: 'planet' | 'wave' | 'torus') => {
    setActiveStage(phase);
    if (phase === 'planet') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (phase === 'wave') {
      const el = document.getElementById('wave-terrain');
      el?.scrollIntoView({ behavior: 'smooth' });
    } else if (phase === 'torus') {
      const el = document.getElementById('torus-singularity');
      el?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const copyUsageCode = () => {
    const snippet = `import ParticleScene from './ParticleScene';

export default function MyPage() {
  return (
    <ParticleScene
      mode="${mode}" // Use 'light' for white/light websites, 'dark' for dark websites
      particleCount={9000}
      colorSphere="${currentTheme.sphere}"
      colorWave="${currentTheme.wave}"
      colorTorus="${currentTheme.torus}"
      turbulenceIntensity={${turbulence}}
      pointSize={${pointSize}}
    />
  );
}`;
    navigator.clipboard.writeText(snippet);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className={`relative min-h-screen font-sans overflow-x-hidden ${isLight ? 'bg-slate-50 text-slate-900' : 'bg-slate-950 text-slate-100'}`}>
      {/* TOP HEADER / LOGO BAR */}
      <header className="fixed top-0 left-0 right-0 z-30 flex items-center justify-between px-6 py-4 pointer-events-none">
        <div className="flex items-center gap-3 pointer-events-auto">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-sky-400 via-purple-500 to-amber-500 flex items-center justify-center shadow-lg shadow-sky-500/20">
            <Sparkles className="w-4 h-4 text-slate-950" />
          </div>
          <div>
            <div className={`text-sm font-bold tracking-tight flex items-center gap-2 ${isLight ? 'text-slate-900' : 'text-white'}`}>
              AetherSwarm <span className={`text-[10px] font-mono font-normal px-2 py-0.5 rounded border ${isLight ? 'bg-slate-200 text-sky-800 border-slate-300' : 'bg-slate-800 text-sky-400 border-slate-700'}`}>WebGL Shader</span>
            </div>
            <div className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>9,000 Points · Single Draw Call</div>
          </div>
        </div>

        <div className="flex items-center gap-2.5 pointer-events-auto">
          {/* Light / Dark Mode Toggle Button */}
          <button
            type="button"
            data-testid="mode-toggle"
            onClick={toggleMode}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all cursor-pointer shadow-sm ${
              isLight
                ? 'border-slate-300 bg-white text-slate-700 hover:bg-slate-100'
                : 'border-slate-700/80 bg-slate-900/80 text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
            aria-label={`Switch to ${isLight ? 'Dark' : 'Light'} Mode`}
          >
            {isLight ? (
              <>
                <Moon className="w-3.5 h-3.5 text-purple-600" />
                <span>Dark View</span>
              </>
            ) : (
              <>
                <Sun className="w-3.5 h-3.5 text-amber-400" />
                <span>Light / White View</span>
              </>
            )}
          </button>

          {/* Embed Code Modal Button */}
          <button
            type="button"
            onClick={() => setShowCodeModal(true)}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-medium border transition-all shadow-sm cursor-pointer ${
              isLight
                ? 'border-slate-300 bg-white text-slate-800 hover:bg-slate-100'
                : 'border-slate-700/80 bg-slate-900/80 text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
            aria-label="View Component Code and Embed Instructions"
          >
            <Code2 className="w-3.5 h-3.5 text-sky-500" />
            <span>Embed Code</span>
          </button>
        </div>
      </header>

      {/* CORE PARTICLE SCENE */}
      <ParticleScene
        mode={mode}
        particleCount={PARTICLE_COUNT}
        colorSphere={currentTheme.sphere}
        colorWave={currentTheme.wave}
        colorTorus={currentTheme.torus}
        turbulenceIntensity={turbulence}
        pointSize={pointSize}
        onMorphChange={(morph) => {
          if (morph < 0.65) setActiveStage('planet');
          else if (morph < 1.45) setActiveStage('wave');
          else setActiveStage('torus');
        }}
      />

      {/* UNIFIED COLLAPSIBLE BOTTOM CONTROL DOCK (Three.js Skill Directive) */}
      <aside
        data-testid="bottom-dock"
        aria-label="Particle Swarm Controls"
        style={{
          position: 'fixed',
          bottom: '20px',
          left: '50%',
          transform: `translateX(-50%) translateY(${isDockCollapsed ? 'calc(100% + 20px)' : '0px'})`,
          maxWidth: 'min(940px, 94vw)',
          transition: 'transform 0.35s cubic-bezier(0.16, 1, 0.3, 1)',
        }}
        className="z-40 w-full"
      >
        {/* Collapse / Expand Toggle Button on Top of Dock */}
        <div className="flex justify-center mb-2">
          <button
            type="button"
            data-testid="toggle-dock"
            onClick={() => setIsDockCollapsed(prev => !prev)}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-mono font-medium shadow-xl cursor-pointer select-none transition-all ${
              isLight
                ? 'bg-white/95 border border-slate-300 text-slate-700 hover:bg-slate-100'
                : 'bg-slate-900/90 border border-slate-700 text-slate-300 hover:bg-slate-800 hover:text-white'
            }`}
            aria-label={isDockCollapsed ? 'Show Particle Controls' : 'Hide Controls (Zen Mode)'}
          >
            {isDockCollapsed ? (
              <>
                <ChevronUp className="w-3.5 h-3.5 text-sky-500" />
                <span>Show Controls (H)</span>
              </>
            ) : (
              <>
                <ChevronDown className={`w-3.5 h-3.5 ${isLight ? 'text-slate-500' : 'text-slate-400'}`} />
                <span>Hide Controls (H)</span>
              </>
            )}
          </button>
        </div>

        {/* Dock Surface */}
        <div className={`rounded-2xl border shadow-2xl p-4 text-xs ${
          isLight
            ? 'border-slate-200/90 bg-white/95 text-slate-800'
            : 'border-slate-800 bg-slate-900/95 text-slate-100'
        }`}>
          <div className="flex flex-wrap items-center justify-between gap-4">
            
            {/* 1. Quick Morph Phase Jumpers */}
            <div className="flex items-center gap-1.5">
              <span className={`text-[11px] font-mono uppercase tracking-wider mr-1 flex items-center gap-1 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                <Layers className="w-3.5 h-3.5 text-sky-500" />
                Morph:
              </span>
              <button
                type="button"
                data-testid="stage-planet"
                onClick={() => scrollToPhase('planet')}
                className={`px-3 py-1.5 rounded-lg font-medium transition-all cursor-pointer ${
                  activeStage === 'planet'
                    ? isLight
                      ? 'bg-sky-100 text-sky-800 border border-sky-300 shadow-sm'
                      : 'bg-sky-500/20 text-sky-300 border border-sky-400/40 shadow-sm'
                    : isLight
                    ? 'text-slate-600 hover:bg-slate-100 border border-transparent'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800 border border-transparent'
                }`}
              >
                1. Planet
              </button>
              <button
                type="button"
                data-testid="stage-wave"
                onClick={() => scrollToPhase('wave')}
                className={`px-3 py-1.5 rounded-lg font-medium transition-all cursor-pointer ${
                  activeStage === 'wave'
                    ? isLight
                      ? 'bg-purple-100 text-purple-800 border border-purple-300 shadow-sm'
                      : 'bg-purple-500/20 text-purple-300 border border-purple-400/40 shadow-sm'
                    : isLight
                    ? 'text-slate-600 hover:bg-slate-100 border border-transparent'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800 border border-transparent'
                }`}
              >
                2. Wave Grid
              </button>
              <button
                type="button"
                data-testid="stage-torus"
                onClick={() => scrollToPhase('torus')}
                className={`px-3 py-1.5 rounded-lg font-medium transition-all cursor-pointer ${
                  activeStage === 'torus'
                    ? isLight
                      ? 'bg-amber-100 text-amber-900 border border-amber-300 shadow-sm'
                      : 'bg-amber-500/20 text-amber-300 border border-amber-400/40 shadow-sm'
                    : isLight
                    ? 'text-slate-600 hover:bg-slate-100 border border-transparent'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800 border border-transparent'
                }`}
              >
                3. Torus
              </button>
            </div>

            <div className={`hidden lg:block w-px h-6 ${isLight ? 'bg-slate-200' : 'bg-slate-800'}`} />

            {/* 2. Color Palette Theme Selectors */}
            <div className="flex items-center gap-2">
              <span className={`text-[11px] font-mono uppercase tracking-wider mr-1 ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                {isLight ? 'Light Theme:' : 'Dark Theme:'}
              </span>
              <div className="flex items-center gap-1.5">
                {themes.map((theme, idx) => (
                  <button
                    key={theme.name}
                    type="button"
                    onClick={() => setSelectedThemeIndex(idx)}
                    title={theme.name}
                    aria-label={`Select ${theme.name} theme`}
                    className={`flex items-center p-1 rounded-md transition-all cursor-pointer ${
                      selectedThemeIndex === idx
                        ? isLight
                          ? 'ring-2 ring-sky-500 bg-slate-100 shadow-sm'
                          : 'ring-2 ring-sky-400 bg-slate-800'
                        : isLight
                        ? 'hover:bg-slate-100 opacity-70 hover:opacity-100'
                        : 'hover:bg-slate-800/80 opacity-70 hover:opacity-100'
                    }`}
                  >
                    <div className="flex -space-x-1">
                      <span className="w-3.5 h-3.5 rounded-full shadow-xs" style={{ backgroundColor: theme.sphere }} />
                      <span className="w-3.5 h-3.5 rounded-full shadow-xs" style={{ backgroundColor: theme.wave }} />
                      <span className="w-3.5 h-3.5 rounded-full shadow-xs" style={{ backgroundColor: theme.torus }} />
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div className={`hidden lg:block w-px h-6 ${isLight ? 'bg-slate-200' : 'bg-slate-800'}`} />

            {/* 3. Sliders: Turbulence & Point Size */}
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <label htmlFor="turbulence-range" className={`text-[11px] font-mono ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                  Turbulence
                </label>
                <input
                  id="turbulence-range"
                  type="range"
                  min="0.2"
                  max="2.5"
                  step="0.1"
                  value={turbulence}
                  onChange={(e) => setTurbulence(parseFloat(e.target.value))}
                  className="w-16 sm:w-20 accent-sky-500 cursor-pointer"
                  aria-label="Particle Turbulence Scale"
                />
                <span className={`font-mono text-[10px] w-7 ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>{turbulence.toFixed(1)}x</span>
              </div>

              <div className="flex items-center gap-2">
                <label htmlFor="point-size-range" className={`text-[11px] font-mono ${isLight ? 'text-slate-500' : 'text-slate-400'}`}>
                  Size
                </label>
                <input
                  id="point-size-range"
                  type="range"
                  min="20"
                  max="60"
                  step="2"
                  value={pointSize}
                  onChange={(e) => setPointSize(parseInt(e.target.value))}
                  className="w-16 sm:w-20 accent-purple-500 cursor-pointer"
                  aria-label="Particle Point Size"
                />
                <span className={`font-mono text-[10px] w-6 ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>{pointSize}</span>
              </div>
            </div>

            {/* 4. Mode Toggle & Reset */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={toggleMode}
                className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                  isLight
                    ? 'border-slate-300 text-slate-700 hover:bg-slate-100'
                    : 'border-slate-700 text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
                title={isLight ? 'Switch to Dark Mode' : 'Switch to Light Mode'}
                aria-label="Toggle Dark and Light Mode"
              >
                {isLight ? <Moon className="w-3.5 h-3.5 text-purple-600" /> : <Sun className="w-3.5 h-3.5 text-amber-400" />}
              </button>

              <button
                type="button"
                onClick={() => {
                  setTurbulence(1.0);
                  setPointSize(38);
                  setSelectedThemeIndex(0);
                }}
                className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
                  isLight
                    ? 'border-slate-300 text-slate-600 hover:bg-slate-100'
                    : 'border-slate-700 text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
                title="Reset to Defaults"
                aria-label="Reset particle parameters"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>

              <div className={`hidden xl:flex items-center gap-1.5 px-2.5 py-1 rounded font-mono text-[10px] border ${
                isLight
                  ? 'bg-slate-100 border-slate-200 text-slate-600'
                  : 'bg-slate-800/80 border-slate-700/60 text-slate-400'
              }`}>
                <Zap className="w-3 h-3 text-emerald-500" />
                <span>60 FPS GPU</span>
              </div>
            </div>

          </div>
        </div>
      </aside>

      {/* EMBED & CODE EXPORT MODAL */}
      {showCodeModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
        >
          <div className={`relative w-full max-w-2xl rounded-2xl border p-6 shadow-2xl text-left max-h-[90vh] overflow-y-auto ${
            isLight
              ? 'border-slate-200 bg-white text-slate-800'
              : 'border-slate-800 bg-slate-900 text-slate-100'
          }`}>
            <div className={`flex items-center justify-between pb-4 border-b ${isLight ? 'border-slate-200' : 'border-slate-800'}`}>
              <div className="flex items-center gap-2.5">
                <Code2 className="w-5 h-5 text-sky-500" />
                <h3 id="modal-title" className="text-base font-bold">
                  Using ParticleScene on White/Light or Dark Websites
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowCodeModal(false)}
                className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                  isLight ? 'text-slate-400 hover:bg-slate-100 hover:text-slate-900' : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                }`}
                aria-label="Close dialog"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="mt-4 space-y-4 text-xs">
              <div className={`p-3.5 rounded-xl border ${
                isLight ? 'bg-amber-50 border-amber-200 text-amber-900' : 'bg-amber-950/40 border-amber-800/40 text-amber-200'
              }`}>
                <strong className="font-semibold block mb-1">How it Works on White / Light Websites:</strong>
                <p className="leading-relaxed">
                  On black backgrounds, 3D scenes use <code>THREE.AdditiveBlending</code> (adding color to black creates vibrant glow). But on a white website, adding colors to white results in <code>(1, 1, 1)</code>, which makes particles completely vanish!
                </p>
                <p className="mt-1.5 leading-relaxed">
                  Passing <code>mode="light"</code> automatically tells the GPU shader to switch to <strong>Normal Blending</strong> with saturated ink pigments and soft alpha falloffs so every particle remains crisp, high-contrast, and beautiful against clean white surfaces!
                </p>
              </div>

              <div>
                <div className="text-[11px] font-mono uppercase text-slate-500 mb-1">1. Install Dependencies:</div>
                <pre className={`p-3 rounded-lg font-mono text-[11px] overflow-x-auto border ${
                  isLight ? 'bg-slate-100 border-slate-200 text-emerald-700' : 'bg-slate-950 border-slate-800 text-emerald-400'
                }`}>
npm install three @react-three/fiber framer-motion&#10;npm install --save-dev @types/three
                </pre>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[11px] font-mono uppercase text-slate-500">2. Drop into your App:</span>
                  <button
                    type="button"
                    onClick={copyUsageCode}
                    className="flex items-center gap-1 text-[11px] text-sky-600 hover:text-sky-500 cursor-pointer font-medium"
                  >
                    {copiedCode ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-600" />
                        <span className="text-emerald-600">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy snippet</span>
                      </>
                    )}
                  </button>
                </div>
                <pre className={`p-3 rounded-lg font-mono text-[11px] overflow-x-auto max-h-48 border ${
                  isLight ? 'bg-slate-100 border-slate-200 text-slate-800' : 'bg-slate-950 border-slate-800 text-slate-200'
                }`}>
{`import ParticleScene from './ParticleScene';

export default function MyPage() {
  return (
    <ParticleScene
      mode="${mode}" // 'light' for white/light websites, 'dark' for dark websites
      particleCount={9000}
      colorSphere="${currentTheme.sphere}"
      colorWave="${currentTheme.wave}"
      colorTorus="${currentTheme.torus}"
      turbulenceIntensity={${turbulence}}
      pointSize={${pointSize}}
    />
  );
}`}
                </pre>
              </div>

              <div className={`p-3.5 rounded-lg border text-[11px] leading-relaxed space-y-2 ${
                isLight ? 'bg-sky-50 border-sky-200 text-sky-950' : 'bg-sky-950/40 border-sky-800/40 text-sky-200'
              }`}>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-sky-500 shrink-0 mt-0.5" />
                  <span><strong>Dual-Mode Shader Engine</strong>: Supports both cosmic additive glow (dark backgrounds) and saturated ink-pigment normal blending (light backgrounds).</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-purple-500 shrink-0 mt-0.5" />
                  <span><strong>Zero React Re-renders on Scroll</strong>: uses Framer Motion scroll motion values sampled directly at 60 FPS in R3F’s <code>useFrame</code>.</span>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                  <span><strong>GPU Staggered Lag & Turbulence</strong>: smoothstep with stochastic delays prevents flat linear morphs.</span>
                </div>
              </div>
            </div>

            <div className="mt-6 flex justify-end">
              <button
                type="button"
                onClick={() => setShowCodeModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-sky-500 hover:bg-sky-400 text-slate-950 transition-colors cursor-pointer"
              >
                Got it
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
